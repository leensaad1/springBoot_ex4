package com.example.ex4_employees;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex4EmployeesApplicationTests {

    @Test
    void contextLoads() {
    }

}
