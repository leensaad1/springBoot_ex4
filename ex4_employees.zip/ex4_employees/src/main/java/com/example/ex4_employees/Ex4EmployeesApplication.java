package com.example.ex4_employees;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex4EmployeesApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ex4EmployeesApplication.class, args);
    }

}
