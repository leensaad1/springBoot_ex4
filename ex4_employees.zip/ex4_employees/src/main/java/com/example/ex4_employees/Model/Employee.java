package com.example.ex4_employees.Model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.hibernate.validator.constraints.Range;

@Data
@AllArgsConstructor
public class Employee {

    @NotNull (message = "id can't be empty")
    @Size(min = 2 ,message = "it should be more than 2 numbers")
    private String id;

    @NotEmpty (message = "name can't be empty")
    @Size (min = 4, message = "it should be more than 4 letters")
    private String name;

    @NotNull(message = "age can't be empty")
    @Min(value = 25, message = "your age must be 25 or more")
    private int age;

    @AssertFalse(message = "it must be false")
    private Boolean onLeave;

    @NotNull(message = "employmentYear can't be empty")
    @Range(min = 1940, max = 2022)
    private int employmentYear;

    @NotNull(message = "annualLeave can't be empty")
    private int annualLeave;

}
