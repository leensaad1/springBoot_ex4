package com.example.ex4_employees.Controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.web.bind.annotation.DeleteMapping;

@Data
@AllArgsConstructor
public class ApiResponse {
    private String message;
}
